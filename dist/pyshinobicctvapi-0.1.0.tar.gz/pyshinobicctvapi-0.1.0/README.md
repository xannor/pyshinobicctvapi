# pyshinobicctvapi
Python wrapper library for the Shinobi CCTV API
